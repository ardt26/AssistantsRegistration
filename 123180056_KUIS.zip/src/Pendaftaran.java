public interface Pendaftaran {
    int hitungRataRata();
    void pengecekan();
}
